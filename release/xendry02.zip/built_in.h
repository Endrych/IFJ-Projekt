/* Nazev - Implementace prekladace imperativniho jazyka IFJ17
 * Petr Zubalik - xzubal04
 * Marek Kukucka - xkukuc04
 * Jan Koci - xkocij01
 * David Endrych - xendry02
 */


#ifndef BUILT_IN_H
#define BUILT_IN_H

void insert_length();

void insert_substr();

void insert_asc();

void insert_chr();

void insert_built_in();


#endif /* BUILT_IN_H */